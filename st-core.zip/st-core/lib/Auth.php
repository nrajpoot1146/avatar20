<?php
namespace lib;
class Auth{
     function __cunstruct()
     {

     }
     function isEmail()
     {

     }
}
 ?>
