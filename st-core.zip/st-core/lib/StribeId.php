<?php
namespace lib;
class StribeId{
	public static function StribeId(){

	}
}
