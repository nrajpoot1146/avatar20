<?php
namespace lib\interfaces;
interface user{
    //public function islogin();
};
 ?>
