<?php
namespace lib\Events;
class Logout{
     function __construct(){

     }

     function __destruct(){
          
     }
}
 ?>
