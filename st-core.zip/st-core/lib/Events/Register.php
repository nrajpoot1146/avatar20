<?php
namespace lib\Events;
class Register{
     function __construct(){

     }

     function __destruct(){
          
     }
}
 ?>
