<?php
namespace lib;
class Validate
{

  function __construct()
  {
    // code...
  }
}

 ?>
