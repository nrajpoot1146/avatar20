<?php
namespace core\rout\interfaces;
interface IRequest
{
    public function getBody();
}

?>
