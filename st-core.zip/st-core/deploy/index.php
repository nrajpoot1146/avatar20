<?php
require_once("../../stribe/autoload.php");

namespace install;
class deploy{
	private $db;
	function __construct(){
		//$db = DB::get
	}
}