<div class="front-footer">
	<div class="clock"></div>
	<!-- ---------------------HOME PAGE SOCIAL ICON BAR RIGHT CORNER------------------- -->
	<div class="cornersocialicon">
		<a class="btn" target="_blank" href="https://www.facebook.com/avatar.recbanda">
			<i class="fa fa-facebook"></i>
		</a>
		<a class="btn" target="_blank" href="https://www.instagram.com/avatar.recbanda">
			<i class="fa fa-instagram"></i>
		</a>
		<a class="btn" target="_blank" href="https://www.twitter.com/avatar_recbanda">
			<i class="fa fa-twitter"></i>
		</a>
		<a class="btn" target="_blank" href="https://www.youtube.com/channel/UCnDez3WnNe476CAjisiWGzQ?view_as=subscriber">
			<i class="fa fa-youtube"></i>
		</a>
		<a class="btn" target="_blank" href="https://www.linkedin.com/company/avatarrecbanda">
			<i class="fa fa-linkedin"></i>
		</a>
	</div>
	<!------------------------------------------------------------------------------------->
</div>
<div class="loader">
	<div style=" position: absolute; top: 42%; left: 48.5%; transform: translate(-50%,-50%);">
		<i class='layer'></i>
		<i class='layer'></i>
		<i class='layer'></i>
	</div>
</div>

<audio id="av-audio">
	<source src="asset/sound/click.mp3" type="audio/mpeg">
</audio>

<script src="https://cdnjs.cloudflare.com/ajax/libs/jqueryui/1.10.3/jquery-ui.js"></script>
<script type="text/javascript" src="<?php echo HOST; ?>asset/js/custom.js"></script>
<script type="text/javascript" src="<?php echo HOST; ?>asset/js/particles.js"></script>
<script type="text/javascript" src="<?php echo HOST; ?>asset/js/app.js"></script>
