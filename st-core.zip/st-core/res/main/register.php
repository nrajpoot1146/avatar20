<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Stribe | Register</title>
	{{head}}
</head>

<body>
	{{header}}
	
	{{footer}}
</body>
</html>