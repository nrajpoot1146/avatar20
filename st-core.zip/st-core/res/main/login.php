<!doctype html>
<html><head>
<meta charset="utf-8">
{{head}}
<title>Stribe | Login</title>
</head>

<body>
	{{header}}
	<div id="wrapper">
		<div>
			<form action="">
				<input type="text" placeholder="username">
				<input type="text" placeholder="password">
				<input type="button" value="submit">
			</form>
		</div>
	</div>
	{{footer}}
</body>
</html>
