<div id="workshop">
<div class="comingsoon">COMING SOON...</div>
</div>