<div id="event_about">
    <p>
        Do you have a thing for memes? Do you have the habit of tagging your best friend in every new
        meme you see? Do you have the skills to make better memes than Facebook troll pages? This is the
        right place to get recognition for your creativity! Register now and participate in the biggest
        platform to showcase your talent and sense of humour. Well, create lit Memes and tell the world
        who's the Memelord.
    </p>
</div>
<!-- ------------------------------Details------------------------------ -->
<div id="event_abstract" style="display: none;">
    <div>
        <h3>MEME SPECIFICATIONS:</h3>
        <ul>
            <li>It should be under 5Mb of size. </li>
            <li> Quality should be maintained. </li>
        </ul>
        <h3>RULES & REGULATIONS: </h3>
        <ul>
            <li> It's not a team based event, only individual participants will be entertained. </li>
            <li>Any kind of vulgar content is highly restricted, otherwise his/her registration will be cancelled & strict action will be taken. </li>
            <li>Use your own mind, copied content will be disqualified. </li>
        </ul>
        <h3>SELECTION PROCEDURE:</h3>
        <ul>
            <li>
                You must share your meme as document on whatsapp (6392714768) and should be mailed at both email addresses mentioned below.
            </li>
            <li>You have to share meme among your friends, social media networks. </li>
            <li>The meme getting most shares on social media will be selected as best. </li>
        </ul>
    </div>
</div>

<!-- --------------------------------contact us----------------------------------- -->
<div id="event_contacts" style="display: none;">
    <div>
        <div class="container-fluid">
            <div class="row">
                <div class="col ml-6">
                    <h3>Mr. Shrikant </h3>
                    <h5><i class="fas fa-envelope"></i>technocratsanam.avtar @gmail.com</h5>
                    <p>&nbsp;<i class="fa fa-phone"></i>
                        +91-7905921533 </p>
                </div>
                <div class="col ml-6">
                    <h3>Mr. Anubhav Yadav </h3>
                    <h5><i class="fas fa-envelope"></i>anubhav.avatar@gmail.com</h5>
                    <p>&nbsp;<i class="fa fa-phone"></i>
                        +91-6392714768 </p>

                </div>
            </div>
        </div>
    </div>
</div>
