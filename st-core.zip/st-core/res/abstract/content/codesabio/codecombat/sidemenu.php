<div class="row m-4">
    <div class="col ml-3 mr-3 p-0" style="box-shadow:2px 2px 25px #1cb096;">
      <img src="asset/img/eventimg/codejam.jpg" style="width:inherit;height:230px;" alt="test">
    </div>
</div>
<div class="row m-4">
    <div class="col p-0">
      <h4 style="text-align:center;color:honeydew;">CodeCombat</h4>
    </div>
</div>
<div class="row m-4">
    <div class="col p-0 text-center">
        <div type="button" class="myButton">Register</div>
    </div>
</div>
