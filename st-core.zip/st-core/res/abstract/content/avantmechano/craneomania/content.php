<div id="event_about">
    <p>
        In this event, the participants have to design a Tower Crane using popsicle sticks cotton strings
        and Fevicol as adhesive (without using any strengthening coating) that can sustain the maximum
        possible load with optimum radius and self-weight, satisfying all the understated constraints.
    </p>
</div>
<!-- ------------------------------Details------------------------------ -->
<div id="event_abstract" style="display: none;">
    <div>
        <h1>Details Coming Soon....</h1>
    </div>
</div>

<!-- --------------------------------contact us----------------------------------- -->
<div id="event_contacts" style="display: none;">
    <div class="coltainer-fluid">
        <div class="row">
            <div class="col-md-6">
                <h3>Mr. Ajay Sharma</h3>
                <h5 style="word-wrap: break-word;"><i class="fas fa-envelope"></i>ajay68236@gmail.com </h5>
                <p>&nbsp;<i class="fa fa-phone"></i>
                    +91-7055358098</p>
            </div>
            <div class="col-md-6">
                <h3>Mr. Maneesh Kumar</h3>
                <h5 style="word-wrap: break-word;"><i class="fas fa-envelope"></i>maneesh.avatar@gmail.com</h5>
                <p>&nbsp;<i class="fa fa-phone"></i>
                    +91-8172834614</p>
            </div>
        </div>
    </div>
</div>
